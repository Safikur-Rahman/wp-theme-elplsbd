<?php
function elpis_bd_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    register_nav_menus(array(
        'primary' => 'Primary Menu',
    ));
}
add_action('after_setup_theme', 'elpis_bd_setup');

function elpis_bd_scripts() {
    wp_enqueue_style('elpis-bd-style', get_stylesheet_uri(), array(), wp_get_theme()->get('Version'));
}
add_action('wp_enqueue_scripts', 'elpis_bd_scripts');

require_once get_template_directory() . '/inc/customizer.php';
