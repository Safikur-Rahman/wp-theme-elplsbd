<?php
// front-page.php
get_header(); ?>
<main>
    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <h1><?php echo esc_html(get_theme_mod('hero_headline', 'Lighting the path forward')); ?></h1>
            <p><?php echo esc_html(get_theme_mod('hero_subheadline', 'One-stop solution for all type IT related issues including Software Development and Digital Marketing which facilitates business leaders to secure sustainable growth.')); ?></p>
            <img src="<?php echo esc_url(get_theme_mod('hero_image', 'https://42f2671d685f51e10fc6-b9fcecea3e50b3b59bdc28dead054ebc.ssl.cf5.rackcdn.com/illustrations/web_developer_p3e5.svg')); ?>" alt="ELPIS BD Hero" class="hero-image" style="background: rgba(255,255,255,0.1); padding: 2rem;">
        </div>
    </section>

    <!-- Our Services (Short) -->
    <section id="services" class="services-section">
        <div class="container">
            <h2 class="section-title">Our Services</h2>
            <p style="text-align: center; max-width: 800px; margin: 0 auto 3rem; color: var(--light-text);">We assign our software development teams to our clients as per their requirements from starting to the end. We offer front-end, backend, database and server solutions for mobile, web and desktop applications. Our mission is to provide expert advice and deliver essential software that drives our clients’ success.</p>
            
            <!-- Service 1 -->
            <div class="service-detail" style="margin-bottom: 5rem; display: flex; flex-wrap: wrap; gap: 3rem; align-items: center;">
                <div style="flex: 1; min-width: 300px; text-align: center;">
                    <img src="<?php echo esc_url(get_theme_mod('service_1_img', 'https://42f2671d685f51e10fc6-b9fcecea3e50b3b59bdc28dead054ebc.ssl.cf5.rackcdn.com/illustrations/programming_2svr.svg')); ?>" alt="Personalized Software Development" style="width: 100%; max-width: 500px; height: auto;">
                </div>
                <div style="flex: 1; min-width: 300px;">
                    <h3 style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;">1. Personalized Software Development</h3>
                    <p style="margin-bottom: 1.5rem; font-size: 1.1rem;">ELPIS partners with you to develop a wide range of customized and complicated software solutions to meet your unique business needs. We listen carefully to your ideas and build personalized software from scratch specifically for your goals. With ELPIS, you can expect top-notch results and reliable service every step of the way.</p>
                </div>
            </div>

            <!-- Service 2 -->
            <div class="service-detail" style="margin-bottom: 5rem; display: flex; flex-wrap: wrap; gap: 3rem; align-items: center; flex-direction: row-reverse;">
                <div style="flex: 1; min-width: 300px; text-align: center;">
                    <img src="<?php echo esc_url(get_theme_mod('service_2_img', 'https://42f2671d685f51e10fc6-b9fcecea3e50b3b59bdc28dead054ebc.ssl.cf5.rackcdn.com/illustrations/web_devices_xw3m.svg')); ?>" alt="Web Application Development" style="width: 100%; max-width: 500px; height: auto;">
                </div>
                <div style="flex: 1; min-width: 300px;">
                    <h3 style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;">2. Web Application Development</h3>
                    <p style="margin-bottom: 1.5rem; font-size: 1.1rem;">ELPIS goes beyond traditional approaches to build unique web products. Our Skilled and experienced web development team recognizes your goals and uses the power of modern web technologies to deliver web applications that bring real value to your business.</p>
                </div>
            </div>

            <!-- Service 3 -->
            <div class="service-detail" style="margin-bottom: 5rem; display: flex; flex-wrap: wrap; gap: 3rem; align-items: center;">
                <div style="flex: 1; min-width: 300px; text-align: center;">
                    <img src="<?php echo esc_url(get_theme_mod('service_3_img', 'https://42f2671d685f51e10fc6-b9fcecea3e50b3b59bdc28dead054ebc.ssl.cf5.rackcdn.com/illustrations/mobile_development_8ygq.svg')); ?>" alt="Mobile Application Development" style="width: 100%; max-width: 500px; height: auto;">
                </div>
                <div style="flex: 1; min-width: 300px;">
                    <h3 style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;">3. Mobile Application Development</h3>
                    <p style="margin-bottom: 1.5rem; font-size: 1.1rem;">Our custom mobile app development service helps our clients to deliver multi-functional features directly to their users’ fingertips. We create high-performance apps that run smoothly on a wide range of devices and operating systems. For native app development, we specialize in Swift and Objective-C for iOS, and Java and Kotlin for Android. When it comes to cross-platform and hybrid solutions, we work with technologies like Ionic, Xamarin, and React Native.</p>
                </div>
            </div>

            <!-- Service 4 -->
            <div class="service-detail" style="margin-bottom: 5rem; display: flex; flex-wrap: wrap; gap: 3rem; align-items: center; flex-direction: row-reverse;">
                <div style="flex: 1; min-width: 300px; text-align: center;">
                    <img src="<?php echo esc_url(get_theme_mod('service_4_img', 'https://42f2671d685f51e10fc6-b9fcecea3e50b3b59bdc28dead054ebc.ssl.cf5.rackcdn.com/illustrations/social_media_marketing_twnp.svg')); ?>" alt="Digital Marketing" style="width: 100%; max-width: 500px; height: auto;">
                </div>
                <div style="flex: 1; min-width: 300px;">
                    <h3 style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;">4. Digital Marketing</h3>
                    <p style="margin-bottom: 1.5rem; font-size: 1.1rem;">ELPIS provides a wide range of technology-driven marketing solutions to help businesses grow their online presence, attract customers, and increase revenue. Our services include Website Design, Landing Pages, SEO, SEM, Social Media Marketing, Content Creation, Email Marketing, CRM integration, Analytics, Reporting, Branding, Creatives, App Marketing etc.</p>
                </div>
            </div>

            <!-- Service 5 -->
            <div class="service-detail" style="margin-bottom: 5rem; display: flex; flex-wrap: wrap; gap: 3rem; align-items: center;">
                <div style="flex: 1; min-width: 300px; text-align: center;">
                    <img src="<?php echo esc_url(get_theme_mod('service_5_img', 'https://42f2671d685f51e10fc6-b9fcecea3e50b3b59bdc28dead054ebc.ssl.cf5.rackcdn.com/illustrations/quality_assurance_7fny.svg')); ?>" alt="Quality Assurance & Testing" style="width: 100%; max-width: 500px; height: auto;">
                </div>
                <div style="flex: 1; min-width: 300px;">
                    <h3 style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;">5. Quality Assurance & Testing</h3>
                    <p style="margin-bottom: 1.5rem; font-size: 1.1rem;">At ELPIS, we blend Agile development and Rational Unified Process practices to make sure our clients get the highest-quality software. In our testing process, our dedicated team members carefully check every part of the product, so it runs smoothly and stays free from bugs or glitches.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- What we Offer Section -->
    <section style="background: var(--white); padding: 80px 0;">
        <div class="container">
            <h2 class="section-title">What we Offer</h2>
            <p style="text-align: center; max-width: 900px; margin: 0 auto 3rem; font-size: 1.1rem;">ELPIS becomes a true part of your development and testing team, working side by side with you to overcome your business challenges and utilize your budget. What sets us apart is the time we invest in understanding your unique needs, demands and difficulties.</p>
            <!-- Offer 1 -->
            <div class="service-detail" style="margin-bottom: 5rem; display: flex; flex-wrap: wrap; gap: 3rem; align-items: center;">
                <div style="flex: 1; min-width: 300px; text-align: center;">
                    <img src="<?php echo esc_url(get_theme_mod('offer_1_img', 'https://42f2671d685f51e10fc6-b9fcecea3e50b3b59bdc28dead054ebc.ssl.cf5.rackcdn.com/illustrations/code_typing_7jnv.svg')); ?>" alt="Qualified Developers" class="offer-image" style="width: 100%; max-width: 500px; height: auto;">
                </div>
                <div style="flex: 1; min-width: 300px;">
                    <h3 style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;">1. Qualified Developers</h3>
                    <p style="font-size: 1.1rem;">ELPIS has expert software developers, and we’re committed to staying at the top of our industry by bringing in talent from leading universities. Our energetic team ensures customer satisfaction through a wide range of technology stacks.</p>
                </div>
            </div>

            <!-- Offer 2 -->
            <div class="service-detail" style="margin-bottom: 5rem; display: flex; flex-wrap: wrap; gap: 3rem; align-items: center; flex-direction: row-reverse;">
                <div style="flex: 1; min-width: 300px; text-align: center;">
                    <img src="<?php echo esc_url(get_theme_mod('offer_2_img', 'https://42f2671d685f51e10fc6-b9fcecea3e50b3b59bdc28dead054ebc.ssl.cf5.rackcdn.com/illustrations/team_collaboration_re_ow29.svg')); ?>" alt="Working as a Team" class="offer-image" style="width: 100%; max-width: 500px; height: auto;">
                </div>
                <div style="flex: 1; min-width: 300px;">
                    <h3 style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;">2. Working as a Team</h3>
                    <p style="font-size: 1.1rem;">Our team becomes yours once you are working with us. We will be your partner to achieve ultimate goal and we’ll face the challenges of software development together and guide you through.</p>
                </div>
            </div>

            <!-- Offer 3 -->
            <div class="service-detail" style="margin-bottom: 5rem; display: flex; flex-wrap: wrap; gap: 3rem; align-items: center;">
                <div style="flex: 1; min-width: 300px; text-align: center;">
                    <img src="<?php echo esc_url(get_theme_mod('offer_3_img', 'https://42f2671d685f51e10fc6-b9fcecea3e50b3b59bdc28dead054ebc.ssl.cf5.rackcdn.com/illustrations/work_together_re_5y58.svg')); ?>" alt="Collaborative Approach" class="offer-image" style="width: 100%; max-width: 500px; height: auto;">
                </div>
                <div style="flex: 1; min-width: 300px;">
                    <h3 style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;">3. Collaborative Approach</h3>
                    <p style="font-size: 1.1rem;">ELPIS is not just a vendor, we become a part of your team. Together, we will follow a collaborative approach to bring your product vision to life, staying in close touch with you at every step of the journey.</p>
                </div>
            </div>

            <!-- Offer 4 -->
            <div class="service-detail" style="margin-bottom: 5rem; display: flex; flex-wrap: wrap; gap: 3rem; align-items: center; flex-direction: row-reverse;">
                <div style="flex: 1; min-width: 300px; text-align: center;">
                    <img src="<?php echo esc_url(get_theme_mod('offer_4_img', 'https://42f2671d685f51e10fc6-b9fcecea3e50b3b59bdc28dead054ebc.ssl.cf5.rackcdn.com/illustrations/project_completed_re_jr7u.svg')); ?>" alt="Continuous Monitoring" class="offer-image" style="width: 100%; max-width: 500px; height: auto;">
                </div>
                <div style="flex: 1; min-width: 300px;">
                    <h3 style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;">4. Continuous Monitoring</h3>
                    <p style="font-size: 1.1rem;">A project manager will be with you throughout the entire project, helping plan, organize, and monitor everything to make sure key milestones and deliverables are met. They will also work on improving processes along the way to keep things running smoothly.</p>
                </div>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
