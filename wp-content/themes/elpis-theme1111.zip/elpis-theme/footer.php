<?php
// footer.php
?>
<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">
            <!-- Column 1: Company Profile -->
            <div class="footer-col footer-col-about">
                <div class="footer-brand">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                        <span class="brand-elpis">ELPIS</span> <span class="brand-bd">BD</span>
                    </a>
                </div>
                <p class="footer-desc">
                    Empowering organizations with cutting-edge enterprise software, cloud infrastructure, and modern digital transformation solutions.
                </p>
                <div class="footer-badge">
                    <span class="badge-dot"></span>
                    <span>Sister concern of SSA International</span>
                </div>
            </div>

            <!-- Column 2: Quick Links & IT Solutions -->
            <div class="footer-col footer-col-links">
                <h4 class="footer-heading">IT Solutions & Links</h4>
                <ul class="footer-links-list">
                    <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><span class="chevron">&rsaquo;</span> Home</a></li>
                    <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'about-us' ) ) ); ?>"><span class="chevron">&rsaquo;</span> About Us</a></li>
                    <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'services' ) ) ); ?>"><span class="chevron">&rsaquo;</span> Enterprise Services</a></li>
                    <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'careers' ) ) ); ?>"><span class="chevron">&rsaquo;</span> Career Opportunities</a></li>
                    <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'contact-us' ) ) ); ?>"><span class="chevron">&rsaquo;</span> Contact & Support</a></li>
                </ul>
            </div>

            <!-- Column 3: Contact & Office Info -->
            <div class="footer-col footer-col-contact">
                <h4 class="footer-heading">Get in Touch</h4>
                <ul class="footer-contact-info">
                    <li>
                        <span class="contact-icon">📍</span>
                        <div class="contact-text">
                            <strong>Head Office:</strong>
                            <span>Dhaka, Bangladesh</span>
                        </div>
                    </li>
                    <li>
                        <span class="contact-icon">✉️</span>
                        <div class="contact-text">
                            <strong>Email:</strong>
                            <a href="mailto:info@elpisbd.com">info@elpisbd.com</a>
                        </div>
                    </li>
                    <li>
                        <span class="contact-icon">📞</span>
                        <div class="contact-text">
                            <strong>Support Hotline:</strong>
                            <a href="tel:+8801700000000">+880 1XXX-XXXXXX</a>
                        </div>
                    </li>
                    <li>
                        <span class="contact-icon">⏰</span>
                        <div class="contact-text">
                            <strong>Working Hours:</strong>
                            <span>Sun - Thu: 10:00 AM - 6:00 PM</span>
                        </div>
                    </li>
                </ul>
            </div>
        </div>

        <div class="footer-bottom">
            <div class="footer-bottom-content">
                <p>&copy; <?php echo date('Y'); ?> <strong>ELPIS BD</strong>. All rights reserved.</p>
                <p class="footer-credit">Sister concern of <strong>SSA International</strong></p>
            </div>
        </div>
    </div>
</footer>

<style>
/* Modern Gorgeous IT Footer Styles */
.site-footer {
    background: #090e1a;
    color: #94a3b8;
    padding: 3rem 0 1.5rem;
    border-top: 1px solid rgba(255, 255, 255, 0.08);
    position: relative;
    font-size: 0.95rem;
}

.site-footer a {
    color: #94a3b8;
    text-decoration: none;
    transition: all 0.25s ease;
}

.site-footer a:hover {
    color: yellow;
}

.footer-grid {
    display: grid;
    grid-template-columns: 1.3fr 1fr 1.2fr;
    gap: 2.5rem;
    margin-bottom: 2rem;
    text-align: left;
}

/* Col 1 Brand */
.footer-brand a {
    text-decoration: none;
    display: inline-block;
    margin-bottom: 0.8rem;
}

.brand-elpis {
    color: yellow;
    font-size: 1.75rem;
    font-weight: 800;
    letter-spacing: 0.5px;
}

.brand-bd {
    color: #3b82f6;
    font-size: 1.75rem;
    font-weight: 800;
}

.footer-desc {
    color: #94a3b8;
    line-height: 1.6;
    margin-bottom: 1.2rem;
    font-size: 0.92rem;
}

.footer-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: rgba(59, 130, 246, 0.1);
    border: 1px solid rgba(59, 130, 246, 0.25);
    color: #60a5fa;
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.82rem;
    font-weight: 500;
}

.badge-dot {
    width: 8px;
    height: 8px;
    background-color: yellow;
    border-radius: 50%;
    display: inline-block;
    box-shadow: 0 0 8px yellow;
}

/* Headings */
.footer-heading {
    color: #ffffff;
    font-size: 1.15rem;
    font-weight: 700;
    margin-bottom: 1rem;
    position: relative;
    padding-bottom: 0.5rem;
    letter-spacing: 0.3px;
}

.footer-heading::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 35px;
    height: 3px;
    background: linear-gradient(90deg, yellow, #3b82f6);
    border-radius: 2px;
}

/* Links List */
.footer-links-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.footer-links-list li {
    margin-bottom: 0.55rem;
}

.footer-links-list a {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    color: #94a3b8;
    transition: transform 0.2s ease, color 0.2s ease;
}

.footer-links-list a .chevron {
    color: yellow;
    font-size: 1.3rem;
    line-height: 1;
    transition: transform 0.2s ease;
}

.footer-links-list a:hover {
    color: yellow;
    transform: translateX(5px);
}

.footer-links-list a:hover .chevron {
    transform: translateX(3px);
}

/* Contact List */
.footer-contact-info {
    list-style: none;
    padding: 0;
    margin: 0;
}

.footer-contact-info li {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    margin-bottom: 0.65rem;
    line-height: 1.45;
}

.contact-icon {
    font-size: 1.1rem;
    flex-shrink: 0;
    margin-top: 1px;
}

.contact-text strong {
    display: block;
    color: #cbd5e1;
    font-size: 0.82rem;
    font-weight: 600;
    margin-bottom: 1px;
}

.contact-text span,
.contact-text a {
    color: #94a3b8;
    font-size: 0.9rem;
}

.contact-text a:hover {
    color: yellow;
}

/* Bottom Bar */
.footer-bottom {
    border-top: 1px solid rgba(255, 255, 255, 0.08);
    padding-top: 1.25rem;
    margin-top: 0.5rem;
}

.footer-bottom-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 0.75rem;
    font-size: 0.88rem;
    color: #64748b;
}

.footer-bottom-content strong {
    color: #e2e8f0;
}

/* Responsive */
@media screen and (max-width: 992px) {
    .footer-grid {
        grid-template-columns: 1fr 1fr;
        gap: 2rem;
    }
    .footer-col-about {
        grid-column: span 2;
    }
}

@media screen and (max-width: 640px) {
    .site-footer {
        padding: 2.25rem 0 1.25rem;
    }
    .footer-grid {
        grid-template-columns: 1fr;
        gap: 1.75rem;
        margin-bottom: 1.5rem;
    }
    .footer-col-about {
        grid-column: span 1;
    }
    .footer-bottom-content {
        flex-direction: column;
        text-align: center;
    }
}
</style>

<?php wp_footer(); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.querySelector('.menu-toggle');
    const closeMenu = document.querySelector('.close-menu');
    const mainNavigation = document.querySelector('.main-navigation');
    const overlay = document.querySelector('.mobile-menu-overlay');
    const menuLinks = document.querySelectorAll('.main-navigation a');

    function toggleMenu() {
        mainNavigation.classList.toggle('active');
        overlay.classList.toggle('active');
        // Prevent body scrolling when menu is open
        document.body.style.overflow = mainNavigation.classList.contains('active') ? 'hidden' : '';
    }

    if(menuToggle) menuToggle.addEventListener('click', toggleMenu);
    if(closeMenu) closeMenu.addEventListener('click', toggleMenu);
    if(overlay) overlay.addEventListener('click', toggleMenu);
    
    // Close menu when a link is clicked
    menuLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (mainNavigation.classList.contains('active')) {
                toggleMenu();
            }
        });
    });
});
</script>
</body>
</html>
