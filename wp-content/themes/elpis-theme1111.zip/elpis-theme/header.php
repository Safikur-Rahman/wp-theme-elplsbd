<?php
// header.php
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ELPIS BD - Enterprise Software Solutions</title>
    <?php wp_head(); ?>
    <style>
        <?php 
            // Helper function to handle px vs auto
            function elpis_size($val) {
                return (is_numeric($val) && $val != '0') ? $val . 'px' : $val;
            }
        ?>
        .hero-image { max-width: <?php echo esc_attr(elpis_size(get_theme_mod('hero_img_max_width', '500'))); ?> !important; max-height: <?php echo esc_attr(elpis_size(get_theme_mod('hero_img_height', 'auto'))); ?> !important; }
        .service-detail img { max-width: <?php echo esc_attr(elpis_size(get_theme_mod('service_img_max_width', '500'))); ?> !important; height: <?php echo esc_attr(elpis_size(get_theme_mod('service_img_height', 'auto'))); ?> !important; }
        .offer-image { max-width: <?php echo esc_attr(get_theme_mod('offer_img_max_width', '100')) . '%'; ?> !important; height: <?php echo esc_attr(elpis_size(get_theme_mod('offer_img_height', 'auto'))); ?> !important; }
        .service-image.leader-img { width: <?php echo esc_attr(elpis_size(get_theme_mod('leader_img_width', '200'))); ?> !important; height: <?php echo esc_attr(elpis_size(get_theme_mod('leader_img_height', '300'))); ?> !important; }
        #careers .hero-image { max-width: <?php echo esc_attr(elpis_size(get_theme_mod('careers_img_max_width', '900'))); ?> !important; max-height: <?php echo esc_attr(elpis_size(get_theme_mod('careers_img_height', 'auto'))); ?> !important; }
    </style>
</head>
<body <?php body_class(); ?>>
<header class="site-header">
    <div class="container header-container">
        <style>
            /* Modern Gorgeous IT Header */
            .site-header {
                background: rgba(9, 14, 26, 0.95) !important;
                backdrop-filter: blur(14px) !important;
                -webkit-backdrop-filter: blur(14px) !important;
                position: sticky;
                top: 0;
                z-index: 1000;
                border-bottom: 1px solid rgba(255, 255, 255, 0.08);
                box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.5) !important;
                padding: 0.85rem 0 !important;
                transition: all 0.3s ease;
            }

            .site-header::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 2px;
                background: linear-gradient(90deg, #facc15 0%, #3b82f6 50%, #60a5fa 100%);
            }

            .header-container {
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            /* Brand Logo */
            .brand-link {
                display: inline-flex;
                align-items: center;
                gap: 10px;
                text-decoration: none;
                transition: transform 0.25s ease;
            }

            .brand-link:hover {
                transform: scale(1.02);
            }

            .brand-logo-icon {
                display: flex;
                align-items: center;
                justify-content: center;
                background: rgba(255, 255, 255, 0.04);
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 8px;
                padding: 6px;
                box-shadow: 0 0 15px rgba(59, 130, 246, 0.2);
            }

            .brand-text {
                font-size: 1.55rem;
                font-weight: 800;
                letter-spacing: 0.5px;
                display: inline-flex;
                align-items: center;
                gap: 6px;
            }

            .brand-elpis {
                color: #facc15;
                text-shadow: 0 0 20px rgba(250, 204, 21, 0.3);
            }

            .brand-bd {
                color: #3b82f6;
                text-shadow: 0 0 20px rgba(59, 130, 246, 0.3);
            }

            /* Nav Wrap */
            .header-nav-wrap {
                display: flex;
                align-items: center;
                gap: 1.8rem;
            }

            /* Navigation Links */
            .main-navigation ul {
                display: flex;
                align-items: center;
                gap: 1.8rem;
                list-style: none;
                margin: 0;
                padding: 0;
            }

            .main-navigation a {
                color: #e2e8f0 !important;
                font-weight: 500;
                font-size: 0.95rem;
                text-decoration: none;
                position: relative;
                padding: 6px 2px;
                transition: color 0.25s ease;
                display: inline-block;
            }

            .main-navigation a::after {
                content: '';
                position: absolute;
                bottom: 0;
                left: 0;
                width: 0;
                height: 2px;
                background: linear-gradient(90deg, #facc15, #3b82f6);
                border-radius: 2px;
                transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            }

            .main-navigation a:hover {
                color: #facc15 !important;
            }

            .main-navigation a:hover::after {
                width: 100%;
            }

            .main-navigation .current-menu-item > a,
            .main-navigation .current_page_item > a {
                color: #facc15 !important;
                font-weight: 600;
            }

            .main-navigation .current-menu-item > a::after,
            .main-navigation .current_page_item > a::after {
                width: 100%;
            }

            /* CTA Button */
            .header-cta-btn {
                display: inline-flex;
                align-items: center;
                gap: 8px;
                background: linear-gradient(135deg, #3b82f6, #1d4ed8);
                color: #ffffff !important;
                font-size: 0.88rem;
                font-weight: 600;
                padding: 0.55rem 1.25rem;
                border-radius: 50px;
                text-decoration: none;
                box-shadow: 0 4px 15px rgba(59, 130, 246, 0.35);
                border: 1px solid rgba(255, 255, 255, 0.15);
                transition: all 0.25s ease;
                white-space: nowrap;
            }

            .header-cta-btn:hover {
                background: linear-gradient(135deg, #2563eb, #1e40af);
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(59, 130, 246, 0.55);
                color: #ffffff !important;
            }

            .header-cta-btn svg {
                transition: transform 0.2s ease;
            }

            .header-cta-btn:hover svg {
                transform: translateX(3px);
            }

            /* Mobile Toggle */
            .menu-toggle {
                background: none;
                border: none;
                cursor: pointer;
                padding: 6px;
                z-index: 1001;
            }

            .menu-toggle .bar {
                background-color: #ffffff !important;
                width: 24px;
                height: 2px;
                margin: 5px auto;
                border-radius: 2px;
                transition: all 0.3s ease;
            }

            .close-menu {
                color: #ffffff !important;
                font-size: 2rem;
            }

            @media screen and (max-width: 1024px) {
                .main-navigation {
                    background: #090e1a !important;
                    border-left: 1px solid rgba(255, 255, 255, 0.08);
                    box-shadow: -10px 0 30px rgba(0, 0, 0, 0.7) !important;
                }
                .header-cta-btn {
                    display: none;
                }
                .main-navigation ul {
                    flex-direction: column;
                    align-items: flex-start;
                    gap: 1.5rem;
                }
                .main-navigation a {
                    font-size: 1.15rem;
                }
            }
        </style>

        <div class="site-title">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="brand-link">
                <span class="brand-logo-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#facc15" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M2 17L12 22L22 17" stroke="#3b82f6" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M2 12L12 17L22 12" stroke="#60a5fa" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </span>
                <span class="brand-text">
                    <span class="brand-elpis">ELPIS</span> <span class="brand-bd">BD</span>
                </span>
            </a>
        </div>
        
        <div class="header-nav-wrap">
            <nav class="main-navigation">
                <button class="close-menu" aria-label="Close Menu">&times;</button>
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'container'      => false,
                    'menu_class'     => '',
                    'fallback_cb'    => function() {
                        ?>
                        <ul>
                            <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
                            <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'about-us' ) ) ); ?>">About Us</a></li>
                            <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'services' ) ) ); ?>">Services</a></li>
                            <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'careers' ) ) ); ?>">Careers</a></li>
                            <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'contact-us' ) ) ); ?>">Contact</a></li>
                        </ul>
                        <?php
                    }
                ));
                ?>
            </nav>

            <a href="<?php echo esc_url( get_permalink( get_page_by_path( 'contact-us' ) ) ); ?>" class="header-cta-btn">
                <span>Get in Touch</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
            </a>

            <button class="menu-toggle" aria-label="Toggle Menu">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </button>
        </div>
        <div class="mobile-menu-overlay"></div>
    </div>
</header>
